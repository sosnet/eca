package TestURLClassLoaderClasses;
public class Pippo implements IPippo {
	
	public Pippo(){ 
		System.out.println("Pippo constructed!"); 
	}
	
	public void met() 
	{
		System.out.println("met"); 
	}
}
