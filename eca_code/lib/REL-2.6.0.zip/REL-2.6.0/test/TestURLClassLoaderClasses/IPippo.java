package TestURLClassLoaderClasses;
public interface IPippo 
{
	public void met();
}
