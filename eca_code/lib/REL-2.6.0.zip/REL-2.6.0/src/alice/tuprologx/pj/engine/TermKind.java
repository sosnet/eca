/*
 * TermKind.java
 *
 * Created on 13 marzo 2007, 14.16
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package alice.tuprologx.pj.engine;

/**
 *
 * @author Maurizio
 */
public enum TermKind {
    INPUT,
    OUTPUT,
    GROUND,
    HIDE;
}
