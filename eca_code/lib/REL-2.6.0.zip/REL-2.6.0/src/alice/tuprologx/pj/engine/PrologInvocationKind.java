/*
 * InvocationKind.java
 *
 * Created on March 12, 2007, 9:10 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package alice.tuprologx.pj.engine;

/**
 *
 * @author maurizio
 */
public enum PrologInvocationKind {
    RELATIONAL,    
    FUNCTIONAL,
    BOOLEAN
}
