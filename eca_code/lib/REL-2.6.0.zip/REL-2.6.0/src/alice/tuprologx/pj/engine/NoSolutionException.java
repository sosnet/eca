/*
 * NoSolutionException.java
 *
 * Created on March 12, 2007, 10:51 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package alice.tuprologx.pj.engine;

/**
 *
 * @author maurizio
 */
@SuppressWarnings("serial")
public class NoSolutionException extends Exception {
    
    /** Creates a new instance of NoSolutionException */
    public NoSolutionException() {
    }
    
}
