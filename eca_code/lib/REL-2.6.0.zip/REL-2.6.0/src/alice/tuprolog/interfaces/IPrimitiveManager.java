package alice.tuprolog.interfaces;

public interface IPrimitiveManager {
	
	boolean containsTerm(String name, int nArgs);

}
