package alice.tuprolog.interfaces;

public interface IEngine {

}
