package alice.tuprolog;

/**
 * Identifier of single subGoal during the demo.
 * @see DefaultSubGoalId
 * 
 * @author Alex Benini
 *
 */
public interface SubGoalId {}